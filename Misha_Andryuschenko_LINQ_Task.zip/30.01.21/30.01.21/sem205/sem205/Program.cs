﻿using System;

namespace sem205
{
    class Program
    {
        //Стандартный шаблон событий
        static void Main(string[] args)
        {
            Pet.SizeChanged += (pet, eventArgs) =>
            {
                //var ourPet1 = pet as Pet;
                //var ourPet2 = (Pet)pet;
                Console.WriteLine($"SIZE OF {((Pet)pet).Name} CHANGED!!! From {eventArgs.OldSize} to {eventArgs.NewSize}");
            };
            
            Pet pet1 = new Pet()
            {
                Name = "Liza",
                Age = 5,
                Size = 10
            };
            
            Pet pet2 = new Pet() 
            {
                Name = "Boo",
                Age = 2,
                Size = 5
            };
            
            pet2.Size = 10;
        }
    }

    class SizeChangedEventArgs : EventArgs
    {
        public double OldSize { get; set; }
        public double NewSize { get; set; }
    }

    delegate void SizeChangedEventHandler(object sender, SizeChangedEventArgs e);
    
    class Pet
    {
        public static event SizeChangedEventHandler SizeChanged;
        public string Name { get; set; }
        public int Age { get; set; }
        private double _size;
        public double Size
        {
            get
            {
                return _size;
            }
            set
            {
                SizeChanged(this,
                    new SizeChangedEventArgs() 
                    {
                        NewSize = value, 
                        OldSize = _size
                    });
                _size = value;
            } 
        }

        private static int maxCountOfPets = 10;
        private static int currentCountOfPets = 0;
        
        public Pet()
        {
            if (currentCountOfPets + 1 <= maxCountOfPets)
            {
                currentCountOfPets++;
            }
            else
            {
                throw new Exception("Count of pets exceeded");
            }
        }
    }
}