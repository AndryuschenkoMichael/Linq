﻿using System;

namespace sem204206
{
    class Program
    {
        //Стандартный шаблон событий
        static void Main(string[] args)
        {
            Cat.NameChanged += (sender, e) =>
            {
                Console.WriteLine($"Name changed from {e.OldName} to {e.NewName} at the age of {e.Age}!");
            };
            
            Cat.NameChanged += (sender, e) =>
            {
                Console.WriteLine($"Hurray!!!");
            };
            
            Cat cat1 = new Cat()
            {
                Age = 1,
                Name = "Nicky"
            };
            
            Cat cat2 = new Cat()
            {
                Age = 2,
                Name = "Marta"
            };

            cat2.Name = "Unknown";
        }
    }

    class NameChangedEventArgs : EventArgs
    {
        public int Age { get; set; }
        public string NewName { get; set; }
        public string OldName { get; set; }
    }

    delegate void NameChangedEventHandler(object sender, NameChangedEventArgs args);
    class Cat
    {
        public static event NameChangedEventHandler NameChanged;
        public int Age { get; set; }

        private string _name;
        public string Name
        {
            get
            {
                return _name;
            }
            set
            {
                NameChanged(
                    this,
                    new NameChangedEventArgs()
                    {
                        Age = Age,
                        NewName = value,
                        OldName = _name
                    });
                
                _name = value;
            }
        }
    }
    
}